'use strict'
let modal = {};

modal.normal = (target) => {
  if (target === "cs-modal") {
    // 모달 작동 변수
    const modal = document.querySelector(".cs-modal");
    const closeBtn = modal.querySelector("button");
    const openBtn = document.querySelector(".modal-button button");
    const overlay = modal.querySelector(".modal-overlay");

    const closeModal = () => {
      modal.classList.remove("show");
    }

    openBtn.addEventListener("click", () => {
      modal.classList.add("show");
    });

    overlay.addEventListener("click", closeModal);
    closeBtn.addEventListener("click", closeModal);
    document.addEventListener("keydown", (event) => {
      if (event.keyCode === 27) {
        modal.classList.remove("show");
      }
    })
  }
}

modal.basic = (target) => {
  if (target === "cs-modal-basic") {
    const openBtn = document.querySelector(".modal-button button");
    const modalBasic = document.querySelector(".cs-modal-basic");
    const divOverlay = document.createElement('div');
    const divContent = document.createElement('div');
    const divItem = document.createElement('div');
    const headOne = document.createElement('h1');
    const btn = document.createElement('button');
    const p = document.createElement('p');
    const nextP = document.createElement('p');
    const nextPTwo = document.createElement('p');
    const code = document.createElement('code');
    const title = document.createTextNode('Charles Modal👍');
    const btnIcon = document.createTextNode('❌');
    const textP = document.createTextNode('모달을 닫으려면 ')
    const textCode = document.createTextNode('ecs ')
    const textNextP = document.createTextNode('버튼을 누르거나 오버레이를')
    const textNextPTwo = document.createTextNode('클릭하거나 닫기 버튼을 클릭하십시오.')

    openBtn.addEventListener("click", () => {
      modalBasic.classList.add("show");
      modalBasic.appendChild(divOverlay);
      divOverlay.classList.add("modal-overlay");
      modalBasic.appendChild(divContent);
      divContent.classList.add("modal-content");
      divContent.appendChild(divItem);
      divItem.classList.add("cs-modal-item");
      divItem.appendChild(headOne);
      // console.log(divItem);
      headOne.appendChild(title);
      divItem.appendChild(btn);
      btn.appendChild(btnIcon);
      divItem.appendChild(p);
      p.appendChild(textP);
      p.classList.add("text");
      divItem.appendChild(code);
      code.appendChild(textCode);
      divItem.appendChild(nextP);
      nextP.appendChild(textNextP);
      nextP.classList.add("text-one");
      divItem.appendChild(nextPTwo);
      nextPTwo.appendChild(textNextPTwo);
      nextPTwo.classList.add("text-two");
    });

    const closeModal = () => {
      modalBasic.classList.remove("show");
    }

    // const overlay = document.querySelector(".modal-overlay");
    // console.log(overlay);
    // console.log(closeBtn);
    divOverlay.addEventListener("click", closeModal);
    btn.addEventListener("click", closeModal);
    document.addEventListener("keydown", (event) => {
      if (event.keyCode === 27) {
        modalBasic.classList.remove("show");
      }
    })
  }


}